#### 10-September-2023
Created a python script for easy insertions into tables in the database.
#### 11-November-2023
Finishing of creating entire, full fledged database and python script.
